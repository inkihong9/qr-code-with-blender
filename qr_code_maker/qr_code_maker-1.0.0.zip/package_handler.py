import os
import sys

# this function imports all libraries stored in the "libs" folder
def import_libs():
    # Path to the "libs" folder inside the extension
    addon_dir = os.path.dirname(__file__)
    libs_dir = os.path.join(addon_dir, "libs")

    # Add to sys.path if not already there
    if libs_dir not in sys.path:
        sys.path.append(libs_dir)